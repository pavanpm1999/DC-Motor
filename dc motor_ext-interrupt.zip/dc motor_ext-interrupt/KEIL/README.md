# Interface Buzzer to demonstrate how External Interrupt works with LPC2148 Microcontroller
